package tn.techcare.PlateformeFormation.model;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;





@Entity
@Table(name ="etatFormation")
public class EtatFormation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_etat ;
	private String etat ;

	@JsonIgnore
	@OneToMany(mappedBy = "etatFormation", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;
	
	public int getId_etat() {
		return id_etat;
	}
	public void setId_etat(int id_etat) {
		this.id_etat = id_etat;
	}
	public String getEtat() {
		return etat;
	}
	public void setEtat(String etat) {
		this.etat = etat;
	}
	
	
}
