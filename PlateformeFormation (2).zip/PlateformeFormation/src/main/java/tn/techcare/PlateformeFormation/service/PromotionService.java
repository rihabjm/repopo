package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Promotion;


public interface PromotionService {

	public List<Promotion>getAllPromotion();
	
}
