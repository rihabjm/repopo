package tn.techcare.PlateformeFormation.service;
import java.util.List ;

import tn.techcare.PlateformeFormation.model.Categorie;

public interface CategorieService {

	public List<Categorie>getAllCategorie();
	
}
