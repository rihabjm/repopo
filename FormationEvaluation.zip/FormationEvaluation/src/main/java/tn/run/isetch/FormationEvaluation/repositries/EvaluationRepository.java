package tn.run.isetch.FormationEvaluation.repositries;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.run.isetch.FormationEvaluation.entites.Evaluation;


public interface EvaluationRepository extends JpaRepository<Evaluation, Integer> {

}
