package tn.run.isetch.FormationEvaluation.repositries;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.run.isetch.FormationEvaluation.entites.Formation;


public interface FormationRepository extends JpaRepository<Formation, Integer> {


	

}
