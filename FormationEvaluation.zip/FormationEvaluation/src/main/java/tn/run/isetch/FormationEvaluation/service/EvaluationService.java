package tn.run.isetch.FormationEvaluation.service;

import tn.run.isetch.FormationEvaluation.entites.Evaluation;

public interface EvaluationService {
	
	public int Evaluer(Evaluation evaluation)  ;
	
	
}
