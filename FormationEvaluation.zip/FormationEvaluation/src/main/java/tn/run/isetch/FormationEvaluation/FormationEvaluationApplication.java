package tn.run.isetch.FormationEvaluation;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class FormationEvaluationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormationEvaluationApplication.class, args);
	}

}
