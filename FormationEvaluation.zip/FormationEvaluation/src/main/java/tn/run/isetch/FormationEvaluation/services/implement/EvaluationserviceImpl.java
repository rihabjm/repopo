package tn.run.isetch.FormationEvaluation.services.implement;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.run.isetch.FormationEvaluation.entites.Evaluation;
import tn.run.isetch.FormationEvaluation.repositries.EvaluationRepository;
import tn.run.isetch.FormationEvaluation.service.EvaluationService;
@Service
public class EvaluationserviceImpl  implements EvaluationService {
	@Autowired
	private EvaluationRepository evaluationrepository ;
	
	@Transactional
	@Override
	public int Evaluer(Evaluation evaluation) {
		evaluationrepository.save(evaluation);
	return 	1 ;
	
	}

		

	
	
}
