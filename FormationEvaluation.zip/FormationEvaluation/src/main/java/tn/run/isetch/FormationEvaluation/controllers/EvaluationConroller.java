package tn.run.isetch.FormationEvaluation.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.run.isetch.FormationEvaluation.entites.Evaluation;
import tn.run.isetch.FormationEvaluation.service.EvaluationService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/evaluation")

public class EvaluationConroller {


	@Autowired
	private EvaluationService evaluationervice ;
	
	@PostMapping("/evaluer")
	public int droitacce (@RequestBody Evaluation evaluation) {
		
	return	evaluationervice.Evaluer(evaluation);
	}

}
