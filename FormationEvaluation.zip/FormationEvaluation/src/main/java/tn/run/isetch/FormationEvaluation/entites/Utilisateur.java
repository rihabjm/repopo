package tn.run.isetch.FormationEvaluation.entites;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Utilisateur")
public class Utilisateur {
	@Id
	@GeneratedValue
	private int cin_utilisateur  ;
	private  String login ;
	private String motdepasse ;
	private String nom ;
	private String prenom ;
	private String photo ;
	public Utilisateur(String string) {
		// TODO Auto-generated constructor stub
	}
	public int getCin_utilisateur() {
		return cin_utilisateur;
	}
	public void setCin_utilisateur(int cin_utilisateur) {
		this.cin_utilisateur = cin_utilisateur;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMotdepasse() {
		return motdepasse;
	}
	public void setMotdepasse(String motdepasse) {
		this.motdepasse = motdepasse;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	
	
}
