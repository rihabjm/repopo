package tn.run.isetch.FormationEvaluation.service;

import java.util.List;

import tn.run.isetch.FormationEvaluation.entites.Formation;

public interface Formationservice {
	public List<Formation> getFormations() ; 
	
}
