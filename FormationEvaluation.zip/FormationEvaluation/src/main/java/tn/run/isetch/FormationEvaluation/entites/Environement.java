package tn.run.isetch.FormationEvaluation.entites;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Environement")
public class Environement {
	@Id
	@GeneratedValue
	private int id_environement ;
	private int numsalle ;
	private String materielles ;
	private String support ;
	public int getId_environement() {
		return id_environement;
	}
	public void setId_environement(int id_environement) {
		this.id_environement = id_environement;
	}
	public int getNumsalle() {
		return numsalle;
	}
	public void setNumsalle(int numsalle) {
		this.numsalle = numsalle;
	}
	public String getMaterielles() {
		return materielles;
	}
	public void setMaterielles(String materielles) {
		this.materielles = materielles;
	}
	public String getSupport() {
		return support;
	}
	public void setSupport(String support) {
		this.support = support;
	}
	
	@OneToMany(mappedBy = "environement", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;
	public List<Formation> getFormations() {
		return formations;
	}
	public void setFormations(List<Formation> formations) {
		this.formations = formations;
	}
	

}
