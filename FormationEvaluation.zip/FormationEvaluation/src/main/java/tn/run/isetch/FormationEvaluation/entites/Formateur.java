package tn.run.isetch.FormationEvaluation.entites;

import java.util.List;

import javax.persistence.OneToMany;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name = "Formateur")
public class Formateur {
	@Id
	@GeneratedValue
	private int id_formateur ;
	private String nom_formateur ;
	
	
    public int getId_formateur() {
		return id_formateur;
	}

	public void setId_formateur(int id_formateur) {
		this.id_formateur = id_formateur;
	}

	public String getNom_formateur() {
		return nom_formateur;
	}

	public void setNom_formateur(String nom_formateur) {
		this.nom_formateur = nom_formateur;
	}
	@JsonIgnore
	@OneToMany(mappedBy = "formateur", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;

	public List<Formation> getFormations() {
		return formations;
	}

	public void setFormations(List<Formation> formations) {
		this.formations = formations;
	}
	
	
}
