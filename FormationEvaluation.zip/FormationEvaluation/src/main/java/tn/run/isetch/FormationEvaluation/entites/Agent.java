package tn.run.isetch.FormationEvaluation.entites;

import javax.persistence.Entity;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Agent")

public class Agent extends Utilisateur {

	public Agent(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

	
}
