package tn.run.isetch.FormationEvaluation.service;



import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import tn.run.isetch.FormationEvaluation.entites.Utilisateur;

public class UtilisateurService {

	public static Utilisateur findByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	

}
