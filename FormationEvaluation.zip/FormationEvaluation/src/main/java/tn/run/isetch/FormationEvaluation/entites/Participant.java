package tn.run.isetch.FormationEvaluation.entites;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Participant")
public class Participant extends Utilisateur {
	  public Participant(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

	@ManyToMany
	    List<Formation> formations  ;
	  
	  @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "contact_id")
	    private Contact contact ;

	public List<Formation> getFormations() {
		return formations;
	}

	public void setFormations(List<Formation> formations) {
		this.formations = formations;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}
	  
	
}
