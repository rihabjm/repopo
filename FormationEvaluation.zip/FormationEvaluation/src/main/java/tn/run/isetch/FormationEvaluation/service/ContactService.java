package tn.run.isetch.FormationEvaluation.service;

import tn.run.isetch.FormationEvaluation.entites.Contact;

public interface ContactService {
	public int ajoutercontact(Contact contact)  ;
}
