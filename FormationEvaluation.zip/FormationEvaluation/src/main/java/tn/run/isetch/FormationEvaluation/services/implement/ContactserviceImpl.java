package tn.run.isetch.FormationEvaluation.services.implement;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.run.isetch.FormationEvaluation.entites.Contact;
import tn.run.isetch.FormationEvaluation.repositries.ContactRepository;
import tn.run.isetch.FormationEvaluation.service.ContactService;





@Service
public class ContactserviceImpl implements ContactService {
	@Autowired
	private ContactRepository contactrepository ;
	
	@Transactional
	@Override
	public int ajoutercontact(Contact contact) {
		
		contactrepository .save(contact);
		
		return 1;
	}
	

	
	
	

}
