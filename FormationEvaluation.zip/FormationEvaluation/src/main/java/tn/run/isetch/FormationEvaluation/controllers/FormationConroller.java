package tn.run.isetch.FormationEvaluation.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.run.isetch.FormationEvaluation.entites.Formation;
import tn.run.isetch.FormationEvaluation.service.Formationservice;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/formation")
public class FormationConroller {

	@Autowired
	private Formationservice formationService ;

	@GetMapping
	private List<Formation> getmembre () {
	return	formationService.getFormations();
	}

	
}
