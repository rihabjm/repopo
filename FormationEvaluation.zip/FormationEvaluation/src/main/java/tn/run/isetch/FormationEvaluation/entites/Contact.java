package tn.run.isetch.FormationEvaluation.entites;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Contact")
public class Contact {
	@Id
	@GeneratedValue
	private int id_contact ;
	private String nom_responsable ;
	private int tel ;
	private String email ;
	private int fax ;
	
	@OneToMany(mappedBy = "contact", cascade = {
	        CascadeType.ALL
	    })
	private List<Participant> participants ;
	public int getId_contact() {
		return id_contact;
	}
	public void setId_contact(int id_contact) {
		this.id_contact = id_contact;
	}
	public String getNom_responsable() {
		return nom_responsable;
	}
	public void setNom_responsable(String nom_responsable) {
		this.nom_responsable = nom_responsable;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
	public int getFax() {
		return fax;
	}
	public void setFax(int fax) {
		this.fax = fax;
	}
	public List<Participant> getParticipants() {
		return participants;
	}
	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}

	

}
