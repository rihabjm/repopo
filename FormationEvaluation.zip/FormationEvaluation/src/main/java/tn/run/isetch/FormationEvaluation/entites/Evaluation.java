package tn.run.isetch.FormationEvaluation.entites;
import javax.persistence.OneToOne;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@org.hibernate.annotations.DiscriminatorOptions(force=true)
@Entity
@Table(name = "Evaluation")
public class Evaluation {
	@Id
	@GeneratedValue
	private int id_evaluation ;
	private int noteFormation ;
	private String suggestion ;
	private String noveaubesoin ;
	@OneToOne
	private Formation formation ;
	@OneToOne
	private Participant participant ;
	public int getId_evaluation() {
		return id_evaluation;
	}
	public void setId_evaluation(int id_evaluation) {
		this.id_evaluation = id_evaluation;
	}
	public int getNoteFormation() {
		return noteFormation;
	}
	public void setNoteFormation(int noteFormation) {
		this.noteFormation = noteFormation;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}
	public String getNoveaubesoin() {
		return noveaubesoin;
	}
	public void setNoveaubesoin(String noveaubesoin) {
		this.noveaubesoin = noveaubesoin;
	}
	public Formation getFormation() {
		return formation;
	}
	public void setFormation(Formation formation) {
		this.formation = formation;
	}
	public Participant getParticipant() {
		return participant;
	}
	public void setParticipant(Participant participant) {
		this.participant = participant;
	}
	

}
