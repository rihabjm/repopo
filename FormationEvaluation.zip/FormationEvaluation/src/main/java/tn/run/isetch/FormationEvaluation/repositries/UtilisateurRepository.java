package tn.run.isetch.FormationEvaluation.repositries;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tn.run.isetch.FormationEvaluation.entites.Utilisateur;

@Repository
public interface UtilisateurRepository extends JpaRepository<Utilisateur, Integer>{

	Utilisateur findByLogin(String username);





}
