package tn.run.isetch.FormationEvaluation.services.implement;

import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import tn.run.isetch.FormationEvaluation.entites.Formation;
import tn.run.isetch.FormationEvaluation.repositries.FormationRepository;
import tn.run.isetch.FormationEvaluation.service.Formationservice;
@Service
public class FormationserviceImpl implements Formationservice  {
	@Autowired
	private FormationRepository formationrepository ;
	
	@Transactional
	@Override
	public List<Formation> getFormations() {
         
		return formationrepository.findAll();
	}

}
