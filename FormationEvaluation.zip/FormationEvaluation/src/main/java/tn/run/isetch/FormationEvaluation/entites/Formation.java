package tn.run.isetch.FormationEvaluation.entites;
import java.sql.Date;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;


import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "Formation")
public class Formation {
	@Id
	@GeneratedValue
	private int id_formation ;
	private String intitule ;
	private Date date ;
	private String lieu ;
    private int note ;
    @JsonIgnore
    @ManyToMany
    List<Participant> participants ;
    @JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "formateur_id")
    private Formateur formateur ;
    
    @JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "environement_id")
    private Environement environement ;
    
  public Environement getEnvironement() {
		return environement;
	}
	public void setEnvironement(Environement environement) {
		this.environement = environement;
	}
	public Formateur getFormateur() {
		return formateur;
	}
	public void setFormateur(Formateur formateur) {
		this.formateur = formateur;
	}
	public List<Participant> getParticipants() {
		return participants;
	}
	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}
	public int getNote() {
		return note;
	}
	public void setNote(int note) {
		this.note = note;
	}
	public int getId_formation() {
		return id_formation;
	}
	public void setId_formation(int id_formation) {
		this.id_formation = id_formation;
	}
	public String getIntitule() {
		return intitule;
	}
	public void setIntitule(String intitule) {
		this.intitule = intitule;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getLieu() {
		return lieu;
	}
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	@Override
	public String toString() {
		return "Formation [id_formation=" + id_formation + ", intitule=" + intitule + ", date=" + date + ", lieu="
				+ lieu + ", note=" + note + ", participants=" + participants + ", formateur=" + formateur
				+ ", environement=" + environement + "]";
	}
	
	

}
