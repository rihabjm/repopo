package tn.run.isetch.FormationEvaluation;

import org.junit.jupiter.api.Test;



class FormationEvaluationApplicationTests {

	@Test
	void contextLoads() {
	
	}

}
